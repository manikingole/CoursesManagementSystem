package com.cmsApp.CoursesManagementSystemApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoursesManagementSystemAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
