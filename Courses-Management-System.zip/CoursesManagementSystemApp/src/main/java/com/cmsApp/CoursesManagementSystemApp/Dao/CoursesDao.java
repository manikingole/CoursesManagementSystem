package com.cmsApp.CoursesManagementSystemApp.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cmsApp.CoursesManagementSystemApp.Entity.Course;

public interface CoursesDao extends JpaRepository<Course,Long>{

}
