package com.cmsApp.CoursesManagementSystemApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoursesManagementSystemAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoursesManagementSystemAppApplication.class, args);
	}

}
