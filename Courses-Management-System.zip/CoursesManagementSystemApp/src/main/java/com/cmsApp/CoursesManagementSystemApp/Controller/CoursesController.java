package com.cmsApp.CoursesManagementSystemApp.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cmsApp.CoursesManagementSystemApp.Entity.Course;
import com.cmsApp.CoursesManagementSystemApp.Service.CoursesService;

@RestController
@RequestMapping("/courses")
public class CoursesController {

	@Autowired
	private CoursesService coursesService;

	// get the courses
	@GetMapping
	public List<Course> getCourse() {
		return this.coursesService.getCourses();
	}

	// get single course
	@GetMapping("/{courseId}")
	public Optional<Course> getCourse(@PathVariable String courseId) {
		return this.coursesService.getCourse(Long.parseLong(courseId));
	}

	// add course
	@PostMapping
	public Course addCourse(@RequestBody Course course) {
		return this.coursesService.addCourse(course);
	}

	// update course
	@PutMapping("/{courseId}")
	public Course updateCourse(@PathVariable Long courseId,@RequestBody Course course) {
		return this.coursesService.updateCourse(courseId,course);
	}

	// delete course
	@DeleteMapping("/{courseId}")
	public String deleteCourse(@PathVariable String courseId) {
		return this.coursesService.deleteCourse(Long.parseLong(courseId));

	}

}
