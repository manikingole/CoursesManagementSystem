package com.cmsApp.CoursesManagementSystemApp.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cmsApp.CoursesManagementSystemApp.Dao.CoursesDao;
import com.cmsApp.CoursesManagementSystemApp.Entity.Course;

@Service
public class CoursesServiceImpl implements CoursesService {
	
	@Autowired
	private CoursesDao coursesDao;
	
	@Override
	public List<Course> getCourses() {
		return coursesDao.findAll();
	}

	@Override
	public Optional<Course> getCourse(Long courseId) {
		return coursesDao.findById(courseId);
	}

	@Override
	public Course addCourse(Course course) {
		return coursesDao.save(course);
	}

	@Override
	public Course updateCourse(Long courseId,Course course) {
		Optional<Course> existingCourseOptional=coursesDao.findById(courseId);
		if(existingCourseOptional.isPresent()) {
			Course existingCourse=existingCourseOptional.get();
			existingCourse.setTitle(course.getTitle());
			return coursesDao.save(existingCourse);
		}
		return null;
	}

	@Override
	public String deleteCourse(long parseLong) {
		Course entity = coursesDao.getOne(parseLong);
		coursesDao.delete(entity);
		return "Delete Course SuccessFul";
	}

}
