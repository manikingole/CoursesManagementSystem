package com.cmsApp.CoursesManagementSystemApp.Service;

import java.util.List;
import java.util.Optional;

import com.cmsApp.CoursesManagementSystemApp.Entity.Course;

public interface CoursesService {
	
	public List<Course> getCourses();

	public Optional<Course> getCourse(Long courseId);

	public Course addCourse(Course course);

	Course updateCourse(Long courseId, Course course);

	public String deleteCourse(long parseLong);

	

}
